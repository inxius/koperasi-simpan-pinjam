<html>
<head>
	<title>tanda bukti transaksi</title>
</head>
<body>

	<center>
		<h2>KOPERASI SIMPAN PINJAM BKM SINDUADI</h2>
    <hr>
		<h4>TANDA BUKTI TRANSAKSI</h4>
	</center>

	<br/>

  <table>
    <tr>
      <td>Nomor Anggota &emsp; &emsp;</td>
      <td>66668888888</td>
    </tr>
    <tr>
      <td>Nama &emsp; &emsp;</td>
      <td>hhhhhhhhhhhh</td>
    </tr>
  </table>
  <hr>
  <table>
    <tr>
      <td>No &emsp;</td>
      <td>Transaksi &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp;</td>
      <td>Nominal &emsp; &emsp;</td>
    </tr>
    <tr>
      <td>1</td>
      <td>simpan</td>
      <td>Rp. 1000000</td>
    </tr>
  </table>
  <hr>


  <br>
  <br>
  <p>-----------------------------------------------------------------------------------------------------------------------------------</p>
  <br>
  <br>
  <center>
    <h2>KOPERASI SIMPAN PINJAM BKM SINDUADI</h2>
    <hr>
    <h4>TANDA BUKTI TRANSAKSI</h4>
  </center>

  <br/>

  <table>
    <tr>
      <td>Nomor Anggota &emsp; &emsp;</td>
      <td>66668888888</td>
    </tr>
    <tr>
      <td>Nama &emsp; &emsp;</td>
      <td>hhhhhhhhhhhh</td>
    </tr>
  </table>
  <hr>
  <table>
    <tr>
      <td>No &emsp;</td>
      <td>Transaksi &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp;</td>
      <td>Nominal &emsp; &emsp;</td>
    </tr>
    <tr>
      <td>1</td>
      <td>simpan</td>
      <td>Rp. 1000000</td>
    </tr>
  </table>
  <hr>
	<script>
		// window.print();
	</script>

</body>
</html>
